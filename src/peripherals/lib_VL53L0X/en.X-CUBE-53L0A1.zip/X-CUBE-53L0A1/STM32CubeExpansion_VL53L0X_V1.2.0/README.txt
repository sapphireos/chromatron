Make sure that you unzip this package in a short path (like C:\Work) as this package
contains many sub-folders and maximum path length supported by Keil/IAR could be
reached (leading to "file not found" errors).